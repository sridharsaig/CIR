Welcome to PyTorch3D's documentation!
=====================================

PyTorch3D is a library of reusable components for Deep Learning with 3D data.

Table of Contents
=================

.. toctree::
   :maxdepth: 2

   overview

.. toctree::
   :maxdepth: 2

   modules/index
